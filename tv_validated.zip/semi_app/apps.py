from django.apps import AppConfig


class SemiAppConfig(AppConfig):
    name = 'semi_app'
